import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  const { messages, tutorName, tutorDesc } = await req.json();

  const systemPrompt = `You are ${tutorName}, a friendly bilingual English tutor on Talkova, an app built for Latino learners. Your personality: ${tutorDesc}

Rules:
- Respond warmly and encouragingly. Never make the learner feel bad.
- When the user makes English grammar or vocabulary mistakes, gently point them out like this: ❌ [wrong] → ✅ [correct] — then briefly explain WHY.
- If they write in Spanish, respond in Spanish AND help them say the same thing in English.
- Keep responses short: 2–4 sentences max. Always end with a follow-up question or task to keep the conversation going.
- Adapt to their level: simplify if they struggle, challenge them if they're doing well.
- Feel like a supportive bilingual friend, not a textbook.`;

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY!,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 1000,
      system: systemPrompt,
      messages,
    }),
  });

  const data = await response.json();
  const reply = data.content?.[0]?.text || 'Lo siento, something went wrong. Try again!';
  return NextResponse.json({ reply });
}
